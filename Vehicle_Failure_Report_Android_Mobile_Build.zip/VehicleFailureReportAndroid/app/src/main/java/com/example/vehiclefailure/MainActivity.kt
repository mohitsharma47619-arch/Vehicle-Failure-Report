package com.example.vehiclefailure

import androidx.activity.ComponentActivity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : ComponentActivity() {
 private val fields=linkedMapOf<String,EditText>()
 private val photos=linkedMapOf<String,MutableList<Uri>>()
  private lateinit var root:LinearLayout
 private val save=registerForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.presentationml.presentation")){ u-> if(u!=null) try { OfflinePptx(this).make(u,fields.mapValues{it.value.text.toString()},photos); toast("PPT report saved") } catch(e:Exception){toast("Error: ${e.message}")} }
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  val scroll=ScrollView(this); root=LinearLayout(this).apply{orientation=1;setPadding(22,18,22,30);setBackgroundColor(Color.rgb(246,249,252))};scroll.addView(root);setContentView(scroll)
  val head=LinearLayout(this).apply{orientation=1;gravity=Gravity.CENTER;setPadding(12,24,12,24);setBackgroundColor(Color.rgb(18,52,90))}
  head.addView(label("TATA MOTORS",25,Color.WHITE,true));head.addView(label("VEHICLE FAILURE REPORT\nConnecting Inspiration",15,Color.WHITE,false));root.addView(head)
  section("1. VEHICLE INFORMATION")
  listOf("Chassis No","Vehicle No","Sale Date","Failure Date","Failure KMs","Customer Name","Contact Number","Vehicle Status").forEach{field(it)}
  section("Failure Type"); val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Warranty","AMC","FMS","Goodwill","FSB"));root.addView(sp);val type=EditText(this);fields["Type"]=type;type.visibility=View.GONE;sp.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:android.widget.AdapterView<*>?){};override fun onItemSelected(p:android.widget.AdapterView<*>?,v:View?,pos:Int,id:Long){type.setText(sp.selectedItem.toString())}}
  section("2. FAILURE ANALYSIS");listOf("Customer Complaint","Observation / Finding","Action Taken","Root Cause").forEach{field(it,true)}
  section("3. VEHICLE PHOTOS (4)");photo("Vehicle Photos",4)
  section("4. KMs / HRS & CHASSIS");photo("KM / HRS Meter Photo",1);photo("Chassis Photo",1)
  section("5–9. VEHICLE FAILURE PHOTOS");(1..5).forEach{photo("Failure Photo $it",1)}
  root.addView(label("Photos and report generation are processed locally on this phone. Internet is not needed after installation.",13,Color.DKGRAY,false))
  val b=Button(this).apply{text="GENERATE POWERPOINT";setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(18,52,90));setOnClickListener{save.launch("Vehicle_Failure_Report.pptx")}};root.addView(b,LinearLayout.LayoutParams(-1,58))
 }
 private fun label(s:String,size:Int,c:Int,b:Boolean)=TextView(this).apply{text=s;textSize=size.toFloat();setTextColor(c);if(b)typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER}
 private fun section(s:String){root.addView(TextView(this).apply{text=s;textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.rgb(18,52,90));setPadding(2,20,2,8)})}
 private fun field(s:String,m:Boolean=false){root.addView(TextView(this).apply{text=s;textSize=13f;setTextColor(Color.DKGRAY);setPadding(2,8,2,2)});val e=EditText(this).apply{hint="Enter $s";textSize=15f;minLines=if(m)3 else 1;setSingleLine(!m);setPadding(12,6,12,6);setBackgroundColor(Color.WHITE)};root.addView(e,LinearLayout.LayoutParams(-1,if(m)104 else 52));fields[s]=e}
 private fun photo(name:String,max:Int){
  val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
  val count=TextView(this).apply{text="0 / $max selected";setPadding(12,0,0,0)}
  // Register each picker while the Activity is being created, not after a button tap.
  val picker=registerForActivityResult(ActivityResultContracts.OpenDocument()){u->
   if(u!=null){try{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};val list=photos.getOrPut(name){mutableListOf()};if(list.size<max)list.add(u);count.text="${list.size} / $max selected"}
  }
  val b=Button(this).apply{text="ADD PHOTO";setOnClickListener{val list=photos.getOrPut(name){mutableListOf()};if(list.size>=max){toast("Maximum reached");return@setOnClickListener};picker.launch(arrayOf("image/*"))}}
  row.addView(b);row.addView(count);root.addView(row)
 }
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}

// Creates a valid, offline OOXML PowerPoint package. Text and selected photo assets are embedded in the file.
private class OfflinePptx(private val a:ComponentActivity){
 private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
 fun make(uri:Uri,data:Map<String,String>,photos:Map<String,List<Uri>>){val parts=linkedMapOf<String,ByteArray>();val slideXml=mutableListOf<String>();val media=mutableListOf<Pair<String,ByteArray>>();val slideRels=mutableListOf("","")
  fun makeSlide(title:String,lines:List<String>,imageName:String?=null):String{val sh=StringBuilder();var id=2;fun txt(t:String,x:Int,y:Int,w:Int,h:Int,sz:Int,b:Boolean=false){sh.append("<p:sp><p:nvSpPr><p:cNvPr id='$id' name='Text$id'/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x='$x' y='$y'/><a:ext cx='$w' cy='$h'/></a:xfrm><a:prstGeom prst='rect'><a:avLst/></a:prstGeom><a:noFill/></p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang='en-US' sz='${sz*100}' b='${if(b)1 else 0}'><a:solidFill><a:srgbClr val='12345A'/></a:solidFill></a:rPr><a:t>${esc(t)}</a:t></a:r></a:p></p:txBody></p:sp>");id++}
   txt(title,500000,250000,11000000,650000,25,true);var y=1100000;lines.forEach{txt(it,650000,y,10500000,if(it.length>95)650000 else 430000,if(it.length>95)13 else 16);y+=if(it.length>95)700000 else 480000}
   if(imageName!=null){sh.append("<p:pic><p:nvPicPr><p:cNvPr id='$id' name='Photo'/><p:cNvPicPr/><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed='rIdImg'/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x='900000' y='1200000'/><a:ext cx='10300000' cy='5200000'/></a:xfrm><a:prstGeom prst='rect'><a:avLst/></a:prstGeom></p:spPr></p:pic>")}
   return "<?xml version='1.0' encoding='UTF-8' standalone='yes'?><p:sld xmlns:a='http://schemas.openxmlformats.org/drawingml/2006/main' xmlns:r='http://schemas.openxmlformats.org/officeDocument/2006/relationships' xmlns:p='http://schemas.openxmlformats.org/presentationml/2006/main'><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val='FFFFFF'/></a:solidFill></p:bgPr></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id='1' name=''/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x='0' y='0'/><a:ext cx='0' cy='0'/><a:chOff x='0' y='0'/><a:chExt cx='0' cy='0'/></a:xfrm></p:grpSpPr>$sh</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>"
  }
  slideXml.add(makeSlide("TATA MOTORS | VEHICLE FAILURE REPORT",listOf("Connecting Inspiration","Vehicle Information")+listOf("Chassis No","Vehicle No","Sale Date","Failure Date","Failure KMs","Type","Customer Name","Contact Number","Vehicle Status").map{"$it: ${data[it].orEmpty().ifBlank{"—"}}"}))
  slideXml.add(makeSlide("FAILURE ANALYSIS",listOf("Customer Complaint","Observation / Finding","Action Taken","Root Cause").map{"$it: ${data[it].orEmpty().ifBlank{"—"}}"}))
  fun addGroup(key:String,title:String){val list=photos[key].orEmpty();if(list.isEmpty()){slideXml.add(makeSlide(title,listOf("No photo added")));slideRels.add("")}else list.forEachIndexed{idx,u->val bmp=a.contentResolver.openInputStream(u)!!.use{BitmapFactory.decodeStream(it)} ?: error("Unsupported image");val stream=ByteArrayOutputStream();bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG,88,stream);val bytes=stream.toByteArray();val name="photo${media.size+1}.jpg";media.add(name to bytes);slideXml.add(makeSlide("$title (${idx+1})",emptyList(),name));slideRels.add("<Relationship Id='rIdImg' Type='http://schemas.openxmlformats.org/officeDocument/2006/relationships/image' Target='../../media/$name'/>")}}
  addGroup("Vehicle Photos","VEHICLE PHOTOS");addGroup("KM / HRS Meter Photo","KM / HRS METER");addGroup("Chassis Photo","CHASSIS PHOTO");(1..5).forEach{addGroup("Failure Photo $it","VEHICLE FAILURE PHOTO $it")};slideXml.add(makeSlide("THANK YOU",listOf("TATA MOTORS","Connecting Inspiration")));slideRels.add("")
  parts["[Content_Types].xml"]=("<?xml version='1.0'?><Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types'><Default Extension='rels' ContentType='application/vnd.openxmlformats-package.relationships+xml'/><Default Extension='xml' ContentType='application/xml'/><Default Extension='jpg' ContentType='image/jpeg'/><Override PartName='/ppt/presentation.xml' ContentType='application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml'/>"+slideXml.indices.joinToString(""){"<Override PartName='/ppt/slides/slide${it+1}.xml' ContentType='application/vnd.openxmlformats-officedocument.presentationml.slide+xml'/>"}+"</Types>").toByteArray()
  parts["_rels/.rels"]="<Relationships xmlns='http://schemas.openxmlformats.org/package/2006/relationships'><Relationship Id='rId1' Type='http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument' Target='ppt/presentation.xml'/></Relationships>".toByteArray()
  parts["ppt/presentation.xml"]=("<p:presentation xmlns:a='http://schemas.openxmlformats.org/drawingml/2006/main' xmlns:r='http://schemas.openxmlformats.org/officeDocument/2006/relationships' xmlns:p='http://schemas.openxmlformats.org/presentationml/2006/main'><p:sldIdLst>"+slideXml.indices.joinToString(""){"<p:sldId id='${256+it}' r:id='rId${it+1}'/>"}+"</p:sldIdLst><p:sldSz cx='12192000' cy='6858000' type='wide'/><p:notesSz cx='6858000' cy='9144000'/></p:presentation>").toByteArray()
  parts["ppt/_rels/presentation.xml.rels"]=("<Relationships xmlns='http://schemas.openxmlformats.org/package/2006/relationships'>"+slideXml.indices.joinToString(""){"<Relationship Id='rId${it+1}' Type='http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide' Target='slides/slide${it+1}.xml'/>"}+"</Relationships>").toByteArray()
  slideXml.forEachIndexed{i,s->parts["ppt/slides/slide${i+1}.xml"]=s.toByteArray();if(slideRels.getOrNull(i).orEmpty().isNotEmpty())parts["ppt/slides/_rels/slide${i+1}.xml.rels"]=("<Relationships xmlns='http://schemas.openxmlformats.org/package/2006/relationships'>${slideRels[i]}</Relationships>").toByteArray()}
  media.forEach{(n,b)->parts["ppt/media/$n"]=b}
  val out=a.contentResolver.openOutputStream(uri)?:error("Cannot write destination");ZipOutputStream(out).use{z->parts.forEach{(n,b)->z.putNextEntry(ZipEntry(n));z.write(b);z.closeEntry()}}
 }
}
