# Vehicle Failure Report – Android source project

Offline-first Android application source for filling vehicle/failure details, selecting photos, and generating a PowerPoint `.pptx` locally on the phone.

## Build the APK
1. Open this folder in Android Studio (Giraffe or newer; Android Gradle Plugin 8.7.3).
2. Allow Android Studio to download the Android build tools / Gradle plugins on the first build.
3. Select **Build → Build APK(s)**.
4. Install the APK on the Android phone.

The installed app does not request Internet permission. Form data and photo selection stay on-device; PPTX generation is local. The initial APK compilation requires Android Studio and its build components.

Included fields: chassis/vehicle number, sale/failure dates, failure KMs, Warranty/AMC/FMS/Goodwill/FSB, customer/contact/status, complaint, findings, action, root cause. Photo slots: 4 vehicle, 1 KM/HRS meter, 1 chassis, 5 failure photos. PPT uses a 16:9 blue/white Tata Motors-inspired layout and Thank You slide.

This package is Android Studio source, not a signed installable APK.

## Build from an Android phone using GitHub Actions
1. Upload `Vehicle_Failure_Report_Android_Source.zip` to the root of a new GitHub repository.
2. In GitHub, create `.github/workflows/build.yml` and paste the contents of `GITHUB_WORKFLOW.yml` (which is included in this project folder).
3. Commit the workflow file. Open the repository's **Actions** tab and wait for **Build Vehicle Failure APK** to finish.
4. Open the completed run, scroll to **Artifacts**, download `Vehicle-Failure-Report-APK`, extract it, and tap `app-debug.apk` to install.
5. If Android asks, allow Chrome or Files to install unknown apps for this installation.

The build itself uses internet on GitHub's servers. The installed app does not need internet to create PPT reports.
